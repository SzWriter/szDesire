$(function(){

    $('#main-buttom').click(function () { 
        $('main').slideToggle();
    });

    $('.usless-a').click(function (e) { 
        e.preventDefault();
    });

    $('.nested-list-show').click(function (e) { 
        e.preventDefault()
        $('#nested-list').slideToggle();
    });

    $('#contact-modal').click(function (e) { 
        e.preventDefault();
        $('#modal').fadeIn();
    });

    $('.modal-btn').click(function () { 
        $('#modal').fadeOut();
    });

    $(window).scroll(function(){
        if ($(this).scrollTop()>=510){
            $('#logo img').attr('src', 'logo/log/Untitled-.png');
            $('#show-menu').css('color','#2f2f2f')
            $('nav a').css('color','#2f2f2f')
            $('nav').css('background','#f5f5f5');
        }else{
            $('#logo img').attr('src', 'logo/log/Untitled.png');
            $('#show-menu').css('color','#f5f5f5')
            $('nav a').css('color','#f5f5f5')
            $('nav').css('background-color','#2f2f2f');
        }
    })
    
})

